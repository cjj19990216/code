package servertransport

import (
	"supernode-calls/server/identifiers"
	"supernode-calls/server/transport"
	"github.com/pion/webrtc/v3"
)

type trackEvent struct {
	ClientID identifiers.ClientID     `json:"clientID"`
	Track    transport.SimpleTrack    `json:"track"`
	Type     transport.TrackEventType `json:"type"`
	SSRC     webrtc.SSRC              `json:"ssrc"`
